package org.eqasim.core.analysis.legs;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;

import org.eqasim.core.analysis.PersonAnalysisFilter;
import org.eqasim.core.components.transit.events.PublicTransitEvent;
import org.matsim.api.core.v01.Id;
import org.matsim.api.core.v01.events.ActivityEndEvent;
import org.matsim.api.core.v01.events.ActivityStartEvent;
import org.matsim.api.core.v01.events.GenericEvent;
import org.matsim.api.core.v01.events.LinkEnterEvent;
import org.matsim.api.core.v01.events.PersonDepartureEvent;
import org.matsim.api.core.v01.events.PersonEntersVehicleEvent;
import org.matsim.api.core.v01.events.PersonLeavesVehicleEvent;
import org.matsim.api.core.v01.events.handler.ActivityEndEventHandler;
import org.matsim.api.core.v01.events.handler.ActivityStartEventHandler;
import org.matsim.api.core.v01.events.handler.GenericEventHandler;
import org.matsim.api.core.v01.events.handler.LinkEnterEventHandler;
import org.matsim.api.core.v01.events.handler.PersonDepartureEventHandler;
import org.matsim.api.core.v01.events.handler.PersonEntersVehicleEventHandler;
import org.matsim.api.core.v01.events.handler.PersonLeavesVehicleEventHandler;
import org.matsim.api.core.v01.network.Network;
import org.matsim.api.core.v01.population.Person;
import org.matsim.api.core.v01.population.PopulationFactory;
import org.matsim.core.api.experimental.events.TeleportationArrivalEvent;
import org.matsim.core.api.experimental.events.handler.TeleportationArrivalEventHandler;
import org.matsim.core.config.ConfigUtils;
import org.matsim.core.router.TripStructureUtils;
import org.matsim.core.scenario.ScenarioUtils;
import org.matsim.core.utils.geometry.CoordUtils;
import org.matsim.vehicles.Vehicle;

public class LegListener implements ActivityStartEventHandler, ActivityEndEventHandler, PersonDepartureEventHandler,
		PersonEntersVehicleEventHandler, PersonLeavesVehicleEventHandler, LinkEnterEventHandler,
		TeleportationArrivalEventHandler, GenericEventHandler {
	final private Network network;

	final private Collection<LegItem> trips = new LinkedList<>();
	final private Map<Id<Person>, LegListenerItem> ongoing = new HashMap<>();
	final private Map<Id<Vehicle>, Collection<Id<Person>>> passengers = new HashMap<>();
	final private Map<Id<Person>, Integer> tripIndex = new HashMap<>();
	final private Map<Id<Person>, Integer> legIndex = new HashMap<>();

	final private PersonAnalysisFilter personFilter;

	public LegListener(Network network, PersonAnalysisFilter personFilter) {
		this.network = network;
		this.personFilter = personFilter;
	}

	public Collection<LegItem> getLegItems() {
		return trips;
	}

	@Override
	public void reset(int iteration) {
		trips.clear();
		ongoing.clear();
		passengers.clear();
		tripIndex.clear();
		legIndex.clear();
	}

	@Override
	public void handleEvent(ActivityEndEvent event) {
		if (personFilter.analyzePerson(event.getPersonId())) {
			Integer localLegIndex = legIndex.get(event.getPersonId());

			if (localLegIndex == null) {
				localLegIndex = 0;
			} else {
				localLegIndex = localLegIndex + 1;
			}

			Integer personTripIndex = tripIndex.get(event.getPersonId());

			if (!TripStructureUtils.isStageActivityType(event.getActType())) {
				if (personTripIndex == null) {
					personTripIndex = 0;
				} else {
					personTripIndex = personTripIndex + 1;
				}
			}

			ongoing.put(event.getPersonId(), new LegListenerItem(event.getPersonId(), personTripIndex, localLegIndex,
					network.getLinks().get(event.getLinkId()).getCoord(), event.getLinkId()));

			tripIndex.put(event.getPersonId(), personTripIndex);
			legIndex.put(event.getPersonId(), localLegIndex);
		}
	}

	@Override
	public void handleEvent(PersonDepartureEvent event) {
		if (personFilter.analyzePerson(event.getPersonId())) {
			ongoing.get(event.getPersonId()).mode = event.getLegMode();
			ongoing.get(event.getPersonId()).departureTime = event.getTime();
		}
	}

	@Override
	public void handleEvent(ActivityStartEvent event) {
		if (personFilter.analyzePerson(event.getPersonId())) {
			LegListenerItem leg = ongoing.remove(event.getPersonId());

			if (leg != null) {
				leg.travelTime = event.getTime() - leg.departureTime;
				leg.destination = network.getLinks().get(event.getLinkId()).getCoord();
				leg.destinationLinkId = event.getLinkId();
				leg.euclideanDistance = CoordUtils.calcEuclideanDistance(leg.origin, leg.destination);

				trips.add(new LegItem(leg.personId, leg.personTripId, leg.legIndex, leg.origin, leg.destination,
						leg.departureTime, leg.travelTime, leg.vehicleDistance, leg.routedDistance, leg.mode,
						leg.euclideanDistance, leg.originLinkId, leg.destinationLinkId));
			}
		}
	}

	@Override
	public void handleEvent(PersonEntersVehicleEvent event) {
		if (personFilter.analyzePerson(event.getPersonId())) {
			if (!passengers.containsKey(event.getVehicleId())) {
				passengers.put(event.getVehicleId(), new HashSet<>());
			}

			passengers.get(event.getVehicleId()).add(event.getPersonId());
		}
	}

	@Override
	public void handleEvent(PersonLeavesVehicleEvent event) {
		if (personFilter.analyzePerson(event.getPersonId())) {
			if (passengers.containsKey(event.getVehicleId())) {
				passengers.get(event.getVehicleId()).remove(event.getPersonId());

				if (passengers.get(event.getVehicleId()).size() == 0) {
					passengers.remove(event.getVehicleId());
				}

				// Last link is not traversed, so we should not count it!
				LegListenerItem item = ongoing.get(event.getPersonId());
				item.routedDistance -= item.lastAddedLinkDistance;
				item.vehicleDistance -= item.lastAddedLinkDistance;
			}
		}
	}

	@Override
	public void handleEvent(LinkEnterEvent event) {
		Collection<Id<Person>> personIds = passengers.get(event.getVehicleId());

		if (personIds != null) {
			personIds.forEach(id -> {
				double linkDistance = network.getLinks().get(event.getLinkId()).getLength();
				LegListenerItem item = ongoing.get(id);

				item.routedDistance += linkDistance;
				item.vehicleDistance += linkDistance;
				item.lastAddedLinkDistance = linkDistance;
			});
		}
	}

	@Override
	public void handleEvent(TeleportationArrivalEvent event) {
		if (personFilter.analyzePerson(event.getPersonId())) {
			LegListenerItem item = ongoing.get(event.getPersonId());
			item.routedDistance += event.getDistance();
		}
	}

	@Override
	public void handleEvent(GenericEvent event) {
		if (event instanceof PublicTransitEvent) {
			PublicTransitEvent transitEvent = (PublicTransitEvent) event;

			if (personFilter.analyzePerson(transitEvent.getPersonId())) {
				LegListenerItem item = ongoing.get(transitEvent.getPersonId());
				item.vehicleDistance += transitEvent.getTravelDistance();
			}
		}
	}
}